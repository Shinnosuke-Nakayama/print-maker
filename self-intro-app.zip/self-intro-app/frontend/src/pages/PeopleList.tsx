import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { fetchData } from "../api";
import type { DataRoot } from "../types";

export default function PeopleList() {
  const [data, setData] = useState<DataRoot | null>(null);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  // =========================
  // データ取得
  // =========================
  useEffect(() => {
    fetchData()
      .then((res) => {
        setData(res);
      })
      .catch((err) => {
        setError(err.message);
      });
  }, []);

  // =========================
  // 表示制御
  // =========================
  if (error) return <p>❌ {error}</p>;
  if (!data) return <p>読み込み中...</p>;

  // =========================
  // 表示
  // =========================
  return (
    <div style={{ padding: 16 }}>
      <h1>人物一覧</h1>

      <button onClick={() => navigate("/edit/new")}>
        ＋ 新規作成
      </button>

      <ul style={{ marginTop: 16 }}>
        {data.people.map((p) => (
          <li key={p.id} style={{ marginBottom: 12 }}>
            <strong>{p.name || "(無名)"}</strong>

            <div style={{ marginTop: 4 }}>
              <button
                onClick={() => navigate(`/person/${p.id}`)}
              >
                表示
              </button>

              <button
                onClick={() => navigate(`/edit/${p.id}`)}
                style={{ marginLeft: 8 }}
              >
                編集
              </button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
