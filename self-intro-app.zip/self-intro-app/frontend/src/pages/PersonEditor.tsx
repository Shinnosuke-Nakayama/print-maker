import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import {
  fetchData,
  saveData,
  uploadImage,
} from "../api";
import type { Person, RadarLabel, DataRoot, RadarModal } from "../types";
import ModalEditor from "../components/ModalEditor"

export default function PersonEditor() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [data, setData] = useState<DataRoot | null>(null);
  const [person, setPerson] = useState<Person | null>(null);
  const [error, setError] = useState("");
  const [uploading, setUploading] = useState(false);
  const [editingLabelIndex, setEditingLabelIndex] =
    useState<number | null>(null);


  // =========================
  // データ取得 & 初期化
  // =========================
  useEffect(() => {
    fetchData()
      .then((res) => {
        setData(res);

        if (id && id !== "new") {
          const existing = res.people.find(
            (p) => p.id === id
          );
          if (!existing) {
            setError("人物が見つかりません");
            return;
          }
          setPerson(existing);
        } else {
          // 新規作成
          setPerson({
            id: crypto.randomUUID(),
            name: "",
            profile: {
              image: "",
              car: "",
            },
            radar: {
              labels: [],
            },
            career: [],
            future: "",
          });
        }
      })
      .catch((err) => setError(err.message));
  }, [id]);

  // =========================
  // 保存
  // =========================
  const save = async () => {
    if (!data || !person) return;

    const updatedPeople =
      id && id !== "new"
        ? data.people.map((p) =>
          p.id === person.id ? person : p
        )
        : [...data.people, person];

    await saveData({ people: updatedPeople });
    navigate("/");
  };

  // =========================
  // 画像アップロード
  // =========================
  const onImageChange = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file || !person) return;

    try {
      setUploading(true);
      const path = await uploadImage(file);

      setPerson({
        ...person,
        profile: {
          ...person.profile,
          image: path, // "/images/xxx.png"
        },
      });
    } catch (err: any) {
      alert(err.message ?? "画像アップロード失敗");
    } finally {
      setUploading(false);
    }
  };

  // =========================
  // ラベル操作
  // =========================
  const addLabel = () => {
    const label: RadarLabel = {
      name: "",
      value: 0,
      modals: [],
    };

    setPerson((prev) =>
      prev
        ? {
          ...prev,
          radar: {
            labels: [...prev.radar.labels, label],
          },
        }
        : prev
    );
  };

  const updateLabel = (
    index: number,
    key: "name" | "value",
    value: string | number
  ) => {
    setPerson((prev) =>
      prev
        ? {
          ...prev,
          radar: {
            labels: prev.radar.labels.map((l, i) =>
              i === index ? { ...l, [key]: value } : l
            ),
          },
        }
        : prev
    );
  };

  const removeLabel = (index: number) => {
    setPerson((prev) =>
      prev
        ? {
          ...prev,
          radar: {
            labels: prev.radar.labels.filter(
              (_, i) => i !== index
            ),
          },
        }
        : prev
    );
  };

  // 経歴追加
  const addCareer = () => {
    setPerson((prev) =>
      prev ? { ...prev, career: [...prev.career, ""] } : prev
    );
  };

  // 経歴更新
  const updateCareer = (index: number, value: string) => {
    setPerson((prev) =>
      prev
        ? {
          ...prev,
          career: prev.career.map((c, i) =>
            i === index ? value : c
          ),
        }
        : prev
    );
  };

  // 経歴削除
  const removeCareer = (index: number) => {
    setPerson((prev) =>
      prev
        ? {
          ...prev,
          career: prev.career.filter((_, i) => i !== index),
        }
        : prev
    );
  };

  const addModal = (labelIndex: number) => {
    setPerson((prev) =>
      prev
        ? {
          ...prev,
          radar: {
            labels: prev.radar.labels.map((l, i) =>
              i === labelIndex
                ? {
                  ...l,
                  modals: [
                    ...l.modals,
                    { image: "", comment: "" },
                  ],
                }
                : l
            ),
          },
        }
        : prev
    );

    setEditingLabelIndex(labelIndex);
  };

  const updateModal = (
    labelIndex: number,
    modalIndex: number,
    modal: RadarModal
  ) => {
    setPerson((prev) =>
      prev
        ? {
          ...prev,
          radar: {
            labels: prev.radar.labels.map((l, i) =>
              i === labelIndex
                ? {
                  ...l,
                  modals: l.modals.map((m, j) =>
                    j === modalIndex ? modal : m
                  ),
                }
                : l
            ),
          },
        }
        : prev
    );
  };

  const removeModal = (
    labelIndex: number,
    modalIndex: number
  ) => {
    setPerson((prev) =>
      prev
        ? {
          ...prev,
          radar: {
            labels: prev.radar.labels.map((l, i) =>
              i === labelIndex
                ? {
                  ...l,
                  modals: l.modals.filter(
                    (_, j) => j !== modalIndex
                  ),
                }
                : l
            ),
          },
        }
        : prev
    );
  };



  // =========================
  // 表示制御
  // =========================
  if (error) return <p>❌ {error}</p>;
  if (!person) return <p>読み込み中...</p>;

  // =========================
  // 表示
  // =========================
  return (
    <div style={{ padding: 16 }}>
      <h1>人物編集</h1>

      {/* 名前 */}
      <div>
        <label>名前：</label>
        <input
          value={person.name}
          onChange={(e) =>
            setPerson({
              ...person,
              name: e.target.value,
            })
          }
        />
      </div>

      {/* 車 */}
      <div>
        <label>車：</label>
        <input
          value={person.profile.car}
          onChange={(e) =>
            setPerson({
              ...person,
              profile: {
                ...person.profile,
                car: e.target.value,
              },
            })
          }
        />
      </div>

      {/* 画像 */}
      <div>
        <label>プロフィール画像：</label>
        <input
          type="file"
          accept="image/*"
          onChange={onImageChange}
        />

        {uploading && <p>アップロード中...</p>}

        {person.profile.image && (
          <div style={{ marginTop: 8 }}>
            <img
              src={`http://localhost:5212${person.profile.image}`}
              alt="profile"
              style={{
                width: 120,
                borderRadius: 8,
              }}
            />
          </div>
        )}
      </div>

      <h3>経歴</h3>

      {person.career.map((c, i) => (
        <div key={i} style={{ marginBottom: 8 }}>
          <input
            style={{ width: "70%" }}
            placeholder="例：2022年 ○○株式会社 入社"
            value={c}
            onChange={(e) =>
              updateCareer(i, e.target.value)
            }
          />
          <button onClick={() => removeCareer(i)}>
            削除
          </button>
        </div>
      ))}

      <button onClick={addCareer}>＋ 経歴追加</button>


      {/* レーダー */}
      <h3>スキル（レーダーチャート）</h3>
      {person.radar.labels.map((l, i) => (
        <div
          key={i}
          style={{
            border: "1px solid #ccc",
            padding: 8,
            marginBottom: 8,
          }}
        >
          <input
            placeholder="ラベル名"
            value={l.name}
            onChange={(e) =>
              updateLabel(i, "name", e.target.value)
            }
          />

          <input
            type="number"
            min={0}
            max={5}
            value={l.value}
            onChange={(e) =>
              updateLabel(i, "value", Number(e.target.value))
            }
            style={{ marginLeft: 8, width: 60 }}
          />

          {/* ★ 追加：詳細編集ボタン */}
          <button
            style={{ marginLeft: 8 }}
            onClick={() => setEditingLabelIndex(i)}
          >
            詳細編集
          </button>

          {/* ★ 既存：削除 */}
          <button
            style={{ marginLeft: 8 }}
            onClick={() => removeLabel(i)}
          >
            削除
          </button>
        </div>
      ))}

      <button onClick={addLabel}>＋ ラベル追加</button>

      <h3>今後の抱負</h3>

      <textarea
        style={{ width: "100%", minHeight: 120 }}
        placeholder="今後挑戦したいこと、目標など"
        value={person.future}
        onChange={(e) =>
          setPerson({ ...person, future: e.target.value })
        }
      />

      {/* 操作 */}
      <div style={{ marginTop: 16 }}>
        <button onClick={save}>保存</button>
        <button onClick={() => navigate("/")}>
          キャンセル
        </button>
      </div>

      {editingLabelIndex !== null && person && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.4)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 1000,
          }}
        >
          <div
            style={{
              background: "#fff",
              padding: 16,
              width: 500,
              maxHeight: "80vh",
              overflowY: "auto",
            }}
          >
            <h3>
              {person.radar.labels[editingLabelIndex].name}
              の詳細
            </h3>

            {person.radar.labels[
              editingLabelIndex
            ].modals.map((m, j) => (
              <ModalEditor
                key={j}
                modal={m}
                onChange={(modal) =>
                  updateModal(editingLabelIndex, j, modal)
                }
                onRemove={() =>
                  removeModal(editingLabelIndex, j)
                }
              />
            ))}

            {/* モーダル追加 */}
            <button
              onClick={() => addModal(editingLabelIndex)}
            >
              ＋ 詳細追加
            </button>

            <div style={{ marginTop: 12 }}>
              <button
                onClick={() => setEditingLabelIndex(null)}
              >
                閉じる
              </button>
            </div>
          </div>
        </div>
      )}



    </div>
  );
}
