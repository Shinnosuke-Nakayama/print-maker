import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { fetchData } from "../api";
import type { DataRoot, Person } from "../types";

import ProfileCard from "../components/ProfileCard";
import RadarChartPanel from "../components/RadarChartPanel";
import "../styles/Selfintro.css";
import "../styles/career.css";

export default function SelfIntro() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [data, setData] = useState<DataRoot | null>(null);
  const [person, setPerson] = useState<Person | null>(null);
  const [error, setError] = useState("");

  // =========================
  // データ取得
  // =========================
  useEffect(() => {
    fetchData()
      .then((res) => {
        setData(res);

        const found = res.people.find((p) => p.id === id);
        setPerson(found ?? null);
      })
      .catch((err) => {
        setError(err.message);
      });
  }, [id]);

  // =========================
  // 表示制御
  // =========================
  if (error) return <p>❌ {error}</p>;
  if (!data) return <p>読み込み中...</p>;
  if (!person) return <p>人物が見つかりません</p>;

  // =========================
  // 表示
  // =========================
  return (
    <div className="app">
      <div className="top-bar">
        <h1>【自己紹介】</h1>

        <div className="top-bar-actions">
          <button onClick={() => navigate("/")}>一覧へ</button>
          <button onClick={() => navigate(`/edit/${person.id}`)}>
            編集
          </button>
        </div>
      </div>


      <div className="grid">
        <div className="panel">
          <h2>【プロフィール】</h2>
          <ProfileCard person={person} />
        </div>

        <div className="panel">
          <h2>【自己評価】</h2>
          <RadarChartPanel person={person} />
        </div>

        <div className="panel">
          <h2>【経歴】</h2>
          <ul>
            {person.career.map((c, i) => (
              <li key={i}>{c}</li>
            ))}
          </ul>
        </div>

        <div className="panel">
          <h2>【今後の抱負】</h2>
          <p>{person.future}</p>
        </div>
      </div>
    </div>
  );
}
