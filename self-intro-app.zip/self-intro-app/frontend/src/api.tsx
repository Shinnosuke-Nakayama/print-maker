import type { DataRoot, Person } from "./types";

const API_BASE = "http://localhost:5212";
const API_URL = `${API_BASE}/api/data`;
const BACKEND_ORIGIN = "http://localhost:5212";

export function resolveImageUrl(path: string) {
  if (path.startsWith("http")) return path;
  return `${BACKEND_ORIGIN}${path}`;
}


/**
 * =====================
 * データ系 API
 * =====================
 */

/**
 * 全データ取得
 */
export async function fetchData(): Promise<DataRoot> {
  const res = await fetch(API_URL);

  if (!res.ok) {
    throw new Error("データ取得に失敗しました");
  }

  return res.json();
}

/**
 * 全データ保存
 */
export async function saveData(data: DataRoot): Promise<void> {
  const res = await fetch(API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });

  if (!res.ok) {
    throw new Error("データ保存に失敗しました");
  }
}

/**
 * ID指定で人物取得（フロント側で抽出）
 */
export async function fetchPersonById(
  id: string
): Promise<Person | null> {
  const data = await fetchData();
  return data.people.find((p) => p.id === id) ?? null;
}

/**
 * 人物を追加 or 更新
 */
export async function upsertPerson(person: Person): Promise<void> {
  const data = await fetchData();

  const exists = data.people.some((p) => p.id === person.id);

  const updated: DataRoot = {
    people: exists
      ? data.people.map((p) =>
          p.id === person.id ? person : p
        )
      : [...data.people, person],
  };

  await saveData(updated);
}

/**
 * =====================
 * 画像アップロード API（← ここを追記）
 * =====================
 */

/**
 * 画像アップロード
 * 戻り値: "/images/xxx.png"
 */
export async function uploadImage(file: File): Promise<string> {
  const form = new FormData();
  form.append("file", file);

  const res = await fetch(`${API_BASE}/api/upload`, {
    method: "POST",
    body: form,
  });

  if (!res.ok) {
    throw new Error("画像アップロードに失敗しました");
  }

  const json: { path: string } = await res.json();
  return json.path;
}
