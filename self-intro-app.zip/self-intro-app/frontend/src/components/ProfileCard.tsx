import type { Person } from "../types";
import "./ProfileCard.css";
import { resolveImageUrl } from "../api"

type Props = {
  person: Person;
};

function ProfileCard({ person }: Props) {
  return (
    <div className="profile-card">
      <img
        src={resolveImageUrl(person.profile.image)}
        style={{
              width: "130px",
              height: "130px",
            }}


        alt={person.name}
        className="profile-image"
      />

      <div className="profile-info">
        <h3 className="profile-name">{person.name}</h3>
        <p className="profile-car">🚙 {person.profile.car}</p>
      </div>
    </div>
  );
}

export default ProfileCard;
