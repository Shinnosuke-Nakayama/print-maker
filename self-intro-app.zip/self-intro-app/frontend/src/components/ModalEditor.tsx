import type { RadarModal } from "../types";
import { uploadImage } from "../api";
import { useState } from "react";

type Props = {
  modal: RadarModal;
  onChange: (modal: RadarModal) => void;
  onRemove: () => void;
};

export default function ModalEditor({
  modal,
  onChange,
  onRemove,
}: Props) {
  const [uploading, setUploading] = useState(false);

  const onImageChange = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setUploading(true);
      const path = await uploadImage(file);

      // ★ ここが profile と違うだけ
      onChange({
        ...modal,
        image: path,
      });
    } catch (err: any) {
      alert(err.message ?? "画像アップロード失敗");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div
      style={{
        border: "1px dashed #999",
        padding: 8,
        marginBottom: 8,
      }}
    >
      {/* 画像 */}
      <div>
        <label>画像：</label>
        <input
          type="file"
          accept="image/*"
          onChange={onImageChange}
        />
        {uploading && <p>アップロード中...</p>}
      </div>

      {/* プレビュー */}
      {modal.image && (
        <img
          src={`http://localhost:5212${modal.image}`}
          style={{ width: "100%", marginTop: 8 }}
        />
      )}

      {/* コメント */}
      <div>
        <label>コメント：</label>
        <textarea
          rows={4}
          style={{
            width: "100%",         // ← 横幅を親いっぱいに
            resize: "vertical",    // ← 縦方向のみリサイズ可
          }}
          value={modal.comment}
          onChange={(e) =>
            onChange({
              ...modal,
              comment: e.target.value,
            })
          }
        />
      </div>

      <button onClick={onRemove}>削除</button>
    </div>
  );
}
