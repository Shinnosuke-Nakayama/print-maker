// components/LabelEditor.tsx
import type { RadarLabel, RadarModal } from "../types";
import ModalEditor from "./ModalEditor";

type Props = {
  label: RadarLabel;
  onChange: (label: RadarLabel) => void;
  onRemove: () => void;
};

export default function LabelEditor({
  label,
  onChange,
  onRemove,
}: Props) {
  const updateModal = (index: number, modal: RadarModal) => {
    const modals = [...label.modals];
    modals[index] = modal;
    onChange({ ...label, modals });
  };

  const addModal = () => {
    onChange({
      ...label,
      modals: [...label.modals, { image: "", comment: "" }],
    });
  };

  const removeModal = (index: number) => {
    onChange({
      ...label,
      modals: label.modals.filter((_, i) => i !== index),
    });
  };

  return (
    <div
      style={{
        border: "1px solid #ccc",
        padding: 10,
        marginBottom: 10,
      }}
    >
      <div>
        <label>ラベル名：</label>
        <input
          value={label.name}
          onChange={(e) =>
            onChange({ ...label, name: e.target.value })
          }
        />
      </div>

      <div>
        <label>値（0〜5）：</label>
        <input
          type="number"
          min={0}
          max={5}
          value={label.value}
          onChange={(e) =>
            onChange({
              ...label,
              value: Number(e.target.value),
            })
          }
        />
      </div>

      <h4>モーダル内容</h4>

      {label.modals.map((modal, i) => (
        <ModalEditor
          key={i}
          modal={modal}
          onChange={(m) => updateModal(i, m)}
          onRemove={() => removeModal(i)}
        />
      ))}

      <button onClick={addModal}>＋ モーダル追加</button>
      <br />
      <button onClick={onRemove} style={{ marginTop: 8 }}>
        ラベル削除
      </button>
    </div>
  );
}
