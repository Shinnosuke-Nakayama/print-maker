import { useState } from "react";
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
  Tooltip,
} from "recharts";
import type { Person, RadarLabel } from "../types";
import "./Modal.css";
import "../App.css";

type Props = {
  person: Person;
};

const API_BASE = "http://localhost:5212";

/** 画像URLを backend 経由に正規化 */
const resolveImageUrl = (path?: string) => {
  if (!path) return "";
  if (path.startsWith("http")) return path;
  return `${API_BASE}${path}`;
};

export default function RadarChartPanel({ person }: Props) {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalTitle, setModalTitle] = useState("");
  const [modalContents, setModalContents] =
    useState<RadarLabel["modals"]>([]);

  const chartData = person.radar.labels.map((label) => ({
    subject: label.name,
    value: label.value,
    fullMark: 5,
  }));

  const handleLabelClick = (labelName: string) => {
    const target = person.radar.labels.find(
      (l) => l.name === labelName
    );
    if (!target) return;

    setModalTitle(target.name);
    setModalContents(target.modals);
    setModalOpen(true);
  };

  return (
    <>
      {/* レーダーチャート */}
      {/* レーダーチャート（カード中央固定） */}
      <div
        style={{
          width: "100%",
          height: 120,              // ← 明示的に高さを与える（重要）
          display: "flex",
          justifyContent: "center", // 横中央
          alignItems: "center",     // 縦中央
          marginLeft: 65
        }}
      >
        <div className="panel-center">
          <div
            style={{
              width: "500px",
              height: "320px",
            }}
          >
            <ResponsiveContainer width="70%" height="100%">
              <RadarChart data={chartData} outerRadius="50%">
                <PolarGrid />
                <PolarAngleAxis
                  dataKey="subject"
                  tick={({ payload, x, y, textAnchor }) => (
                    <text
                      x={x}
                      y={y}
                      textAnchor={textAnchor}
                      style={{
                        cursor: "pointer",
                        fill: "black",
                        fontSize: 14,
                        textDecoration: "underline",
                      }}
                      onClick={() =>
                        handleLabelClick(payload.value)
                      }
                    >
                      {payload.value}
                    </text>
                  )}
                />
                <PolarRadiusAxis domain={[0, 5]} fontSize={12} />
                <Radar
                  dataKey="value"
                  stroke="#1976d2"
                  fill="#1976d2"
                  fillOpacity={0.6}
                />
                <Tooltip />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>


      {/* モーダル */}
      {modalOpen && (
        <div
          className="modal-overlay"
          onClick={() => setModalOpen(false)}
        >
          <div
            className="modal"
            onClick={(e) => e.stopPropagation()}
          >
            <h3>{modalTitle}</h3>

            {modalContents.map((m, i) => (
              <div key={i} className="modal-item">
                {m.image && (
                  <img
                    src={resolveImageUrl(m.image)}
                    alt=""
                  />
                )}
                <p>{m.comment}</p>
              </div>
            ))}

            <button onClick={() => setModalOpen(false)}>
              閉じる
            </button>
          </div>
        </div>
      )}
    </>
  );
}
