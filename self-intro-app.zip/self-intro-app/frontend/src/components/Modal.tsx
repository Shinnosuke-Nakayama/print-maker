// src/components/Modal.tsx

type ModalProps = {
  open: boolean;
  onClose: () => void;
  title: string;
  image: string;
  comment: string;
};

export function Modal({
  open,
  onClose,
  title,
  image,
  comment,
}: ModalProps) {
  if (!open) return null;

  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.5)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 1000,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          background: "#fff",
          padding: "20px",
          width: "300px",
          maxHeight: "80vh",   // ← 重要
          overflowY: "auto",   // ← 重要
          borderRadius: "8px",
        }}
      >
        <h2>{title}</h2>

        {image && (
          <img
            src={image}
            alt={title}
            style={{ width: "100%", marginBottom: "10px" }}
          />
        )}

        <p>{comment}</p>

        <button onClick={onClose}>閉じる</button>
      </div>
    </div>
  );
}
