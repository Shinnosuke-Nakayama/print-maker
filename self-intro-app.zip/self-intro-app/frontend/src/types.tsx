export type RadarModal = {
  image: string;
  comment: string;
};

export type RadarLabel = {
  name: string;
  value: number; // 0〜5
  modals: RadarModal[];
};

export type Radar = {
  labels: RadarLabel[];
};

export type Profile = {
  image: string;
  car: string;
};

export type Person = {
  id: string;
  name: string;
  profile: Profile;
  radar: Radar;
  career: string[];
  future: string;
};

export type DataRoot = {
  people: Person[];
};
