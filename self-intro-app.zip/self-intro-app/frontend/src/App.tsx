import { BrowserRouter, Routes, Route } from "react-router-dom";
import SelfIntro from "./pages/SelfIntro";
import PeopleList from "./pages/PeopleList";
import PersonEditor from "./pages/PersonEditor";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* 人一覧 */}
        <Route path="/" element={<PeopleList />} />

        {/* 自己紹介画面 */}
        <Route path="/person/:id" element={<SelfIntro />} />

        {/* 編集（新規・既存） */}
        <Route path="/edit/:id" element={<PersonEditor />} />
        <Route path="/edit/new" element={<PersonEditor />} />
      </Routes>
    </BrowserRouter>
  );
}
