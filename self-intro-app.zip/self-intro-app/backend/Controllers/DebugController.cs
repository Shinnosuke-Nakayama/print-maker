using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/debug")]
public class DebugController : ControllerBase
{
    private readonly IWebHostEnvironment _env;

    public DebugController(IWebHostEnvironment env)
    {
        _env = env;
    }

    [HttpGet("path")]
    public object GetPath()
    {
        var path = Path.Combine(_env.ContentRootPath, "Data", "data.json");

        return new
        {
            path,
            exists = System.IO.File.Exists(path)
        };
    }
}
