using Microsoft.AspNetCore.Mvc;
using System.Linq;

[ApiController]
[Route("api/data")]
public class DataController : ControllerBase
{
    private readonly JsonFileService _service;

    public DataController(JsonFileService service)
    {
        _service = service;
    }

    // =====================
    // 全データ取得
    // GET /api/data
    // =====================
    [HttpGet]
    public ActionResult<DataRoot> Get()
    {
        return Ok(_service.Load());
    }

    // =====================
    // 全体を丸ごと保存
    // POST /api/data
    // =====================
    [HttpPost]
    public IActionResult Save([FromBody] DataRoot data)
    {
        _service.Save(data);
        return Ok(new { message = "saved" });
    }

    // =====================
    // 人を1人追加
    // POST /api/data/person
    // =====================
    [HttpPost("person")]
    public IActionResult AddPerson([FromBody] Person newPerson)
    {
        var root = _service.Load();

        if (root.People == null)
        {
            root.People = new List<Person>();
        }

        if (root.People.Any(p => p.Id == newPerson.Id))
        {
            return BadRequest(new { message = "ID already exists" });
        }

        root.People.Add(newPerson);
        _service.Save(root);

        return Ok(new { message = "person added" });
    }

    // =====================
    // 人の情報を更新
    // PUT /api/data/{id}
    // =====================
    [HttpPut("{id}")]
    public IActionResult UpdatePerson(string id, [FromBody] Person updated)
    {
        var root = _service.Load();

        var target = root.People.FirstOrDefault(p => p.Id == id);
        if (target == null) return NotFound();

        target.Name = updated.Name;
        target.Profile = updated.Profile;
        target.Radar = updated.Radar;
        target.Career = updated.Career;
        target.Future = updated.Future;

        _service.Save(root);

        return Ok(new { message = "updated" });
    }

    // =====================
    // ★ 画像パスだけ更新（追加）
    // PUT /api/data/{id}/image
    // =====================
    [HttpPut("{id}/image")]
    public IActionResult UpdatePersonImage(string id, [FromBody] ImageUpdateRequest req)
    {
        var root = _service.Load();

        var target = root.People.FirstOrDefault(p => p.Id == id);
        if (target == null) return NotFound();

        target.Profile.Image = req.ImagePath;

        _service.Save(root);

        return Ok(new { message = "image updated" });
    }
}

// DTO（小さくてOK）
public class ImageUpdateRequest
{
    public string ImagePath { get; set; } = "";
}
