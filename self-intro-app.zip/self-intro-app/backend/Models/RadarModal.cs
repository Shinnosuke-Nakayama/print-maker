public class RadarModal
{
    public string Image { get; set; }
    public string Comment { get; set; }
}
