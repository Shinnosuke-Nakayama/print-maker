public class Person
{
    public string Id { get; set; }
    public string Name { get; set; }
    public Profile Profile { get; set; }
    public Radar Radar { get; set; }
    public List<string> Career { get; set; }
    public string Future { get; set; }
}
