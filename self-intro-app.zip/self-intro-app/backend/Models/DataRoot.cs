public class DataRoot
{
    public List<Person> People { get; set; }
}
