public class RadarLabel
{
    public string Name { get; set; }
    public int Value { get; set; }
    public List<RadarModal> Modals { get; set; }
}
