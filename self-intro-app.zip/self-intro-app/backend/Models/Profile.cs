public class Profile
{
    public string Image { get; set; }
    public string Car { get; set; }
}
