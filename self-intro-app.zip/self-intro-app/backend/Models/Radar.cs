public class Radar
{
    public List<RadarLabel> Labels { get; set; }
}
