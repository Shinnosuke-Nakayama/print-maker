using System.Text.Json;

public class JsonFileService
{
    private readonly string _filePath;

    public JsonFileService(IWebHostEnvironment env)
    {
        _filePath = Path.Combine(
            env.ContentRootPath,
            "Data",
            "data.json"
        );

        // 起動時に Data フォルダ / data.json が無ければ作成
        var dir = Path.GetDirectoryName(_filePath);
        if (!Directory.Exists(dir))
        {
            Directory.CreateDirectory(dir!);
        }

        if (!File.Exists(_filePath))
        {
            var empty = new DataRoot
            {
                People = new List<Person>()
            };

            var json = JsonSerializer.Serialize(
                empty,
                new JsonSerializerOptions { WriteIndented = true }
            );

            File.WriteAllText(_filePath, json);
        }
    }

    // =====================
    // 読み込み
    // =====================
    public DataRoot Load()
    {
        var json = File.ReadAllText(_filePath);

        var result = JsonSerializer.Deserialize<DataRoot>(
            json,
            new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            }
        );

        // 念のための保険
        if (result == null)
        {
            return new DataRoot
            {
                People = new List<Person>()
            };
        }

        if (result.People == null)
        {
            result.People = new List<Person>();
        }

        return result;
    }

    // =====================
    // 保存
    // =====================
    public void Save(DataRoot data)
    {
        // null 保険
        if (data.People == null)
        {
            data.People = new List<Person>();
        }

        var json = JsonSerializer.Serialize(
            data,
            new JsonSerializerOptions
            {
                WriteIndented = true
            }
        );

        File.WriteAllText(_filePath, json);
    }
}
